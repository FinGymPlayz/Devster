import handler.main as npp
import handler.log as log

npp.color.text.pipe("lime")
npp.color.text.colon("cyan")
npp.color.secondary("#181818")
npp.color.rcmenu("red")
npp.color.text.dot("#BD00FF")


npp.main()