import handler.main as npp
import handler.log as log
from tkinter import *
from threading import Thread
import time
import os
from time import strftime
import clipboard

def qs():
    with open("c:/npnp/handler/dat/livetext.txt") as f:
        content = f.read()
    if os.path.exists("c:/npnp/handler/qs/") == False:
        os.mkdir("c:/npnp/handler/qs/")
    format = strftime("%d_%M_%Y_%H_%M_%S")
    print(format)
    with open(f"c:/npnp/handler/qs/quick_save_data_{format}.txt",'w+') as f:
        f.write(content)
    os.system("start c:/npnp/handler/qs/")

def copy_func():
    with open("c:/npnp/handler/dat/livetext.txt") as f:
        content = f.read()
    clipboard.copy(content)

def add_btns():
    time.sleep(1)
    quicksave = Button(text="Quicksave",bg=npp.secondarycolor,fg=npp.fgc,command=qs)
    quicksave.pack(anchor="e",side="right")
    
    copy = Button(text="Copy",bg=npp.secondarycolor,fg=npp.fgc,command=copy_func)
    copy.pack(anchor="e",side="right")
    
    social = Button(text="Social",bg=npp.secondarycolor,fg=npp.fgc,command=lambda: os.system("start http://npnp.lifeserverf.org/social/"))
    social.pack(anchor="w",side="left")
    
    new = Button(text="New",bg=npp.secondarycolor,fg=npp.fgc,command=npp.main)
    new.pack(anchor="w",side="left")

thread = Thread(target=add_btns)
thread.start()

npp.main()